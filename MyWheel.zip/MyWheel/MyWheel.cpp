#include "MyWheel.h"
#include "Arduino.h"
#include <SPI.h>  

struct motor
{
	int pin_up;
	int pin_down;
	int pin_speed;
};
motor* MotorRight;
motor* MotorLeft;

void MyClass::begin(int pinUpR, int pinDownR, int pinSpeedR, int pinUpL, int pinDownL, int pinSpeedL)
{
	MotorRight = new motor();
	MotorLeft = new motor();
	
	MotorRight->pin_up = pinUpR;
	MotorRight->pin_down = pinDownR;
	MotorRight->pin_speed = pinSpeedR;
	MotorLeft->pin_up = pinUpL;
	MotorLeft->pin_down = pinDownL;
	MotorLeft->pin_speed = pinSpeedL;

	pinMode(MotorRight->pin_up, OUTPUT);
	pinMode(MotorRight->pin_down, OUTPUT);
	pinMode(MotorLeft->pin_up, OUTPUT);
	pinMode(MotorLeft->pin_down, OUTPUT);
	
}

void MyClass::Wheel(motor* motorStruct, int v)
{
	if (v>100) v = 100;
	if (v<-100) v = -100;
	if (v>0) {
		digitalWrite(motorStruct->pin_up, HIGH);
		digitalWrite(motorStruct->pin_down, LOW);
		analogWrite(motorStruct->pin_speed, v*2.55);
	}
	else if (v<0) {
		digitalWrite(motorStruct->pin_up, LOW);
		digitalWrite(motorStruct->pin_down, HIGH);
		analogWrite(motorStruct->pin_speed, (-v)*2.55);
	}
	else {
		digitalWrite(motorStruct->pin_up, LOW);
		digitalWrite(motorStruct->pin_down, LOW);
		analogWrite(motorStruct->pin_speed, 0);
	}
}

void MyClass::controlMotors(int x1, int x2)
{
	Wheel(MotorRight, x2 - x1);
	Wheel(MotorLeft, x2 + x1);
}
 


