#ifndef MyWheel_h
#define MyWheel_h
#include "Arduino.h"
#include <SPI.h>      
class MyClass
{
public:
	struct motor
	{
		int pin_up;
		int pin_down;
		int pin_speed;
	};
	motor* MotorRight;
	motor* MotorLeft;
	void begin(int pinUpR, int pinDownR, int pinSpeedR, int pinUpL, int pinDownL, int pinSpeedL);
	void Wheel(motor* motorStruct, int v);
	void controlMotors(int x1, int x2);
	
private:
	
};
#endif