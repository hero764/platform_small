#ifndef Radio_h
#define Radio_h

#include "Arduino.h"
#include <SPI.h>             
#include <nRF24L01.h>        
#include <RF24.h> 
class Lbr
{
public:
	const int ce = 9;
	const int csn = 10;
	uint64_t address[10] = { 0xF0F0F0F000, 0xF0F0F0F011, 0xF0F0F0F022, 0xF0F0F0F033, 0xF0F0F0F044, 0xF0F0F0F055 };
	RF24 *radio;
	int msg[2];
	int x1;
	int x2;
	int x;
	int y;
	//byte pipeNo;
	
	Lbr();

	void begin();
	void startListening(byte channel);
	void startWriting(byte channel);
	void receive(int &x, int &y);
	void transmitte(int x, int y);
};
#endif