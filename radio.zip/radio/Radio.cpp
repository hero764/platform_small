#include "Radio.h"
#include <SPI.h>             
#include <nRF24L01.h>        
#include <RF24.h>  
#include "Arduino.h"

Lbr::Lbr(){}

void Lbr::begin()
  

  
{
  radio = new RF24(9, 10);  
  radio->begin();    
  radio->setAutoAck(1);       
  radio->setRetries(0,15);     
  radio->enableAckPayload();   
  radio->setPayloadSize(sizeof(msg));    
  radio->setChannel(0x70);  
  radio->setPALevel (RF24_PA_MAX); 
  radio->setDataRate (RF24_1MBPS); 
  radio->powerUp();
        
}                                 
                

void Lbr::startListening(byte channel)
  
  
{
  
  radio->openReadingPipe(1,address[channel]);
  radio->startListening();
}

void Lbr::startWriting(byte channel)
  

{
    radio->openWritingPipe (address[channel]);
    radio->stopListening();
}


void Lbr::receive(int &x, int &y)
{
	
	if (radio->available())
	{
		radio->read(&msg, sizeof(msg));
		x = msg[0];
		y = msg[1];
		//x1 = map(msg[0], 0, 1023, -100, 100);
		//x2 = map(msg[1], 0, 1023, -100, 100);
	}
	else
	{
		Serial.print("Radio is not available\n");
	}
}

void Lbr::transmitte(int x, int y)
  
  
{

  msg[0] = x;
  msg[1] = y;
  
  radio->write(&msg, sizeof(msg));
}